# دفتري — Daftri

تطبيق دفتر حسابات وديون يعمل بدون إنترنت.

## المحتويات
- `www/` : التطبيق كاملاً (index.html). افتحه في أي متصفح لتجربته.
- `android/` : مشروع Android Studio جاهز (Kotlin + WebView) يعرض نفس التطبيق.

## الطريقة 1: Android Studio (الأفضل)
1. ثبّت Android Studio.
2. File > Open ثم اختر المجلد `android`.
3. انتظر Gradle Sync (يحتاج إنترنت أول مرة).
4. للتجربة: Run على جوالك أو المحاكي.
5. لملف APK: Build > Build Bundle(s) / APK(s) > Build APK(s). تجده في `app/build/outputs/apk/debug/`.
6. للنشر على المتجر: Build > Generate Signed Bundle / APK ووقّع بمفتاحك.

## الطريقة 2: مواقع تحويل الويب إلى APK
اضغط مجلد `www` كملف ZIP (يجب أن يكون index.html في جذر الـ ZIP) وارفعه في موقع يحوّل HTML إلى APK.
في هذه الطريقة قد لا تعمل أزرار النسخ والمشاركة والطباعة وفتح واتساب كما في Android Studio.

## الخط (اختياري)
ضع `Cairo-Regular.ttf` و`Cairo-Bold.ttf` داخل `fonts/` في `www` وفي `android/app/src/main/assets/www`.

## ملاحظات
- البيانات تُحفظ على الجهاز. التطبيق يبدأ فارغًا، ومن «المزيد» يمكنك تحميل بيانات تجريبية.
- «الكاشف» نتائجه تجريبية، والحقيقي يحتاج خادمًا وقاعدة بيانات مشتركة بين المحلات.
- تفعيل الاشتراك تجريبي: أي كود بصيغة DAF-XXXX-XXXX يعمل. للتحقق الحقيقي تحتاج خادمًا.
- لم أبنِ APK هنا لعدم توفر Android SDK، فلم أجرّب بناء Gradle.
