ضع هنا ملفي خط Cairo (اختياري) بهذين الاسمين بالضبط:
Cairo-Regular.ttf
Cairo-Bold.ttf
حمّلهما من Google Fonts. إذا لم تضعهما سيستخدم التطبيق خط النظام.
